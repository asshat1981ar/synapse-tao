# Coverage Report

| Module | Coverage | Status |
|--------|----------|--------|
| SelfAnalysisEngine | 92% | ✅ |
| SelfCorrector | 87% | 🚧 |
| SelfLearner | 94% | ✅ |
| taoLoopService | 89% | 🚧 |
